import model.*;
import service.RouteGenerator;
import service.ShortestDeliveryTimeCalculator;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        List<Location> locations = new ArrayList<>();

        List<DeliveryPerson> deliveryPersonList = initDeliveryPerson();
        List<Restaurant> restaurantList = initRestaurant();
        List<Customer> customerList = initCustomers(restaurantList);

        deliveryPersonList.forEach(deliveryPerson -> locations.add(deliveryPerson.getDeliveryPersonLocation()));
        restaurantList.forEach(restaurant -> locations.add(restaurant.getRestaurantLocation()));
        customerList.forEach(customer -> locations.add(customer.getCustomerLocation()));

        Map<Location,Customer> customerMap =  getLocationToCustomerMap(customerList);
        Map<Location,Restaurant> restaurantMap = getLocationToRestaurantMap(restaurantList);


        // Generate all possible routes
        List<Route> routes = RouteGenerator.generateRoutes(locations, deliveryPersonList.get(0),customerMap,restaurantMap);


        double pt1 = 0.5;
        double pt2 = 0.7;

        // calculate shortest time
        double shortestTime = ShortestDeliveryTimeCalculator.shortestDeliveryTime(routes, pt1, pt2);

        // Output the result
        System.out.println("Shortest time to deliver the batch: " + shortestTime + " hours");
    }

    /**
     * returns List of Customers
     */

    public static List<Customer> initCustomers(List<Restaurant> restaurants) {
        List<Customer> customerList = new ArrayList<>();


        // customers are taking food from restaurants of choice

        Customer customer1 = new Customer("C1", "Rahul", "rk@gmail.com", "8978675432",
                new CustomerLocation(12.9581, 77.7110), restaurants.get(0));

        Customer customer2 = new Customer("C2", "Rohan", "rkv@gmail.com", "8978675433",
                new CustomerLocation(12.9081, 77.6476), restaurants.get(1));

        customerList.add(customer1);
        customerList.add(customer2);
        return customerList;
    }

    /**
     * returns List of Restaurant
     */

    public static List<Restaurant> initRestaurant() {
        List<Restaurant> restaurants = new ArrayList<>();

        Restaurant restaurant1 = new Restaurant("R1", "Moti Mahal Deluxe",
                new RestaurantLocation(12.9345, 77.6254));

        Restaurant restaurant2 = new Restaurant("R2", "Bharat Jalpan",
                new RestaurantLocation(12.9345, 77.6254));

        restaurants.add(restaurant1);
        restaurants.add(restaurant2);

        return restaurants;
    }

    /**
     * returns List of Delivery Persons
     */
    public static List<DeliveryPerson> initDeliveryPerson(){
        List<DeliveryPerson> deliveryPersons = new ArrayList<>();

        DeliveryPerson aman = new DeliveryPerson("D1","Aman","aman@gmail.com","8765432109",
                new DeliveryPersonLocation(12.9304, 77.6209));

        deliveryPersons.add(aman);
        return deliveryPersons;
    }

    /**
     * returns Map of Location to Customer
     */
    public static Map<Location,Customer> getLocationToCustomerMap(List<Customer> customerList){
        Map<Location,Customer> customerMap = new HashMap<>();

        customerList.forEach(customer -> {
            customerMap.put(customer.getCustomerLocation(),customer);
        });
        return customerMap;
    }

    /**
     * returns Map of Location to Restaurant
     */
    public static Map<Location,Restaurant> getLocationToRestaurantMap(List<Restaurant> restaurantList){
        Map<Location,Restaurant> restaurantMap = new HashMap<>();

        restaurantList.forEach(restaurant -> {
            restaurantMap.put(restaurant.getRestaurantLocation(),restaurant);
        });
        return restaurantMap;
    }

}