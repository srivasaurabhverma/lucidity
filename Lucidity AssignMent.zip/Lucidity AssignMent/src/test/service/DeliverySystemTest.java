package test.service;

import org.testng.annotations.Test;
import static org.testng.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import model.*;
import service.RouteGenerator;
import service.ShortestDeliveryTimeCalculator;

public class DeliverySystemTest {

    @Test
    public void testRouteGeneration() {
        // Given
        List<Location> locationList = new ArrayList<>();

        List<DeliveryPerson> deliveryPersons = initTestDeliveryPerson();
        List<Restaurant> restaurants = initTestRestaurant();
        List<Customer> customers = initTestCustomers(restaurants);

        deliveryPersons.forEach(deliveryPerson -> locationList.add(deliveryPerson.getDeliveryPersonLocation()));
        restaurants.forEach(restaurant -> locationList.add(restaurant.getRestaurantLocation()));
        customers.forEach(customer -> locationList.add(customer.getCustomerLocation()));

        assertTrue(locationList.size() > 0);

        Map<Location, Customer> customerMap = getLocationToCustomerMap(customers);
        Map<Location, Restaurant> restaurantMap = getLocationToRestaurantMap(restaurants);

        // When
        List<Route> routes = RouteGenerator.generateRoutes(locationList, deliveryPersons.get(0), customerMap, restaurantMap);

        // Then
        assertNotNull(routes);
        assertTrue(routes.size() > 0);
    }

    @Test
    public void testShortestDeliveryTimeCalculation() {
        List<Route> routes = new ArrayList<>();

        double pt1 = 0.5;
        double pt2 = 0.7;

        // When
        double shortestTime = ShortestDeliveryTimeCalculator.shortestDeliveryTime(routes, pt1, pt2);

        // Then
        assertTrue(shortestTime >= 0); // Ensure the shortest time is non-negative
    }
    public static List<Customer> initTestCustomers(List<Restaurant> restaurants) {
        List<Customer> customerList = new ArrayList<>();


        // customers are taking food from restaurants of choice

        Customer customer1 = new Customer("C1", "Rahul", "rk@gmail.com", "8978675432",
                new CustomerLocation(12.9581, 77.71108), restaurants.get(0));

        Customer customer2 = new Customer("C2", "Rohan", "rkv@gmail.com", "8978675433",
                new CustomerLocation(12.9081, 77.6476), restaurants.get(1));

        customerList.add(customer1);
        customerList.add(customer2);
        return customerList;
    }

    public static List<Restaurant> initTestRestaurant() {
        List<Restaurant> restaurants = new ArrayList<>();

        Restaurant restaurant1 = new Restaurant("R1", "Moti Mahal Deluxe",
                new RestaurantLocation(12.9345, 77.62543));

        Restaurant restaurant2 = new Restaurant("R2", "Bharat Jalpan",
                new RestaurantLocation(12.9345, 77.6254));

        restaurants.add(restaurant1);
        restaurants.add(restaurant2);

        return restaurants;
    }

    public static List<DeliveryPerson> initTestDeliveryPerson(){
        List<DeliveryPerson> deliveryPersons = new ArrayList<>();

        DeliveryPerson aman = new DeliveryPerson("D1","Aman","aman@gmail.com","8765432109",
                new DeliveryPersonLocation(12.9304, 77.6209));

        deliveryPersons.add(aman);
        return deliveryPersons;
    }

    public static Map<Location,Customer> getLocationToCustomerMap(List<Customer> customerList){
        Map<Location,Customer> customerMap = new HashMap<>();

        customerList.forEach(customer -> {
            customerMap.put(customer.getCustomerLocation(),customer);
        });
        return customerMap;
    }

    public static Map<Location,Restaurant> getLocationToRestaurantMap(List<Restaurant> restaurantList){
        Map<Location,Restaurant> restaurantMap = new HashMap<>();

        restaurantList.forEach(restaurant -> {
            restaurantMap.put(restaurant.getRestaurantLocation(),restaurant);
        });
        return restaurantMap;
    }
}
