package service;

import model.Route;

import java.util.List;

public class ShortestDeliveryTimeCalculator {

    /**
     * returns minimum Time taken to deliver the order to respective customer by delivery person (aman)
     */
    public static double shortestDeliveryTime(List<Route> routes, double pt1, double pt2) {
        double shortestTime = Double.MAX_VALUE;
        for (Route route : routes) {
            double totalTime = TimeCalculator.calculateTotalTime(route, pt1, pt2);
            shortestTime = Math.min(shortestTime, totalTime);
        }
        return shortestTime;
    }

}
