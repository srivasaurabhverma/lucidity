package enums;

public enum LocationType {
    RESTAURANT,
    CUSTOMER,
    DELIVERY_PERSON
}
