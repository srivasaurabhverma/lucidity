package model;

import enums.LocationType;

public class DeliveryPersonLocation extends Location{
    public DeliveryPersonLocation(double latitude, double longitude) {
        super(latitude, longitude, LocationType.DELIVERY_PERSON);
    }
}
