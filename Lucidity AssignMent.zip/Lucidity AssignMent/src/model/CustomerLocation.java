package model;

import enums.LocationType;

public class CustomerLocation extends Location{
    public CustomerLocation(double latitude, double longitude) {
        super(latitude, longitude, LocationType.CUSTOMER);
    }
}
