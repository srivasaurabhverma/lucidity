package model;

import enums.LocationType;

public class Location {
    double latitude;
    double longitude;
    LocationType type;

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public LocationType getType() {
        return type;
    }

    public void setType(LocationType type) {
        this.type = type;
    }

    public Location(double latitude, double longitude, LocationType type) {
        this.latitude = latitude;
        this.longitude = longitude;
        this.type = type;
    }
}
