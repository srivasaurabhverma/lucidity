package model;

import enums.LocationType;

public class RestaurantLocation extends Location{

    public RestaurantLocation(double latitude, double longitude) {
        super(latitude, longitude, LocationType.RESTAURANT);
    }
}
