package model;

public class Restaurant {
    String id;
    String name;
    RestaurantLocation restaurantLocation;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public RestaurantLocation getRestaurantLocation() {
        return restaurantLocation;
    }

    public void setRestaurantLocation(RestaurantLocation restaurantLocation) {
        this.restaurantLocation = restaurantLocation;
    }

    public Restaurant(String id, String name, RestaurantLocation restaurantLocation) {
        this.id = id;
        this.name = name;
        this.restaurantLocation = restaurantLocation;
    }
}
