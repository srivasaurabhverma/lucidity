package model;

import java.util.ArrayList;
import java.util.List;

public class Route {
    List<Location> locations;

    public Route() {
        this.locations = new ArrayList<>();
    }

    public void addLocation(Location location) {
        locations.add(location);
    }

    public List<Location> getLocations() {
        return locations;
    }

}
